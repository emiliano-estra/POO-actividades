﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
           /* 4.Se debe desarrollar un programa que pida el ingreso del precio de un artículo y 
              la cantidad que lleva el cliente. Mostrar lo que debe abonar el comprador.*/
            int num1, num2, abono;
            string linea;

            Console.Write("introducir el precio del articulo:");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("introducir cantidad de articulos a llevar:");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            abono = num1 * num2 ;

            Console.WriteLine("debe abonar:");
            Console.WriteLine(abono);
            Console.ReadKey();
        }
    }
}
