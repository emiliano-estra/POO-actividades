﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
           /* 2.Escribir un programa en el cual se ingresen cuatro números, 
           calcular e informar la suma de los dos primeros y el producto del tercero y el cuarto.*/
            int num1, num2, num3, num4, producto, suma;
            string linea;

            Console.Write("introducir un numero para sumar:");
            linea = Console.ReadLine();
            num1=int.Parse(linea);

            Console.Write("introducir otro numero para sumar:");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            Console.Write("introducir un numero para multiplicar:");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            Console.Write("introducir otro numero para multiplicar:");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            suma = num1 + num2;

            producto = num3 * num4;
            Console.WriteLine("la suma es:");
            Console.WriteLine(suma);
            Console.WriteLine("la multiplicacion es:");
            Console.WriteLine(producto);
            Console.ReadKey();
        }
    }
}
