﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto5
{
    internal class Program
    {
        static void Main(string[] args)
        {
           /* 5.Realizar la carga del radio de un círculo, mostrar por pantalla la circunferencia y
            el área del mismo(La circunferencia se calcula multiplicando el doble del radio por π (pi), y el área se calcula multiplicando π por el cuadrado del radio).*/
            int num1;
            double π = 3.1416, circunferencia, area;
            string linea;

            Console.Write("introducir el radio de tu circulo:");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            circunferencia = 2 * num1 * π;
            area = num1 * num1 * π;

            Console.WriteLine("circunferencia del circulo:");
            Console.WriteLine(circunferencia);
            Console.WriteLine("area del circulo:");
            Console.WriteLine(area);
            Console.ReadKey();
        }
    }
}
