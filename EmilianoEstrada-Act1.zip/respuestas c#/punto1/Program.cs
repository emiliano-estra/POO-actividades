﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
           /* 1.Realizar la carga del lado de un cuadrado, mostrar por pantalla el perímetro 
             del mismo(El perímetro de un cuadrado se calcula multiplicando el valor del lado por cuatro).*/

            int ladocuadrado,perimetro;
            string linea;

            Console.Write("ingrese lado del cuadrado para calcular su perimetro:");
            linea = Console.ReadLine();
            ladocuadrado=int.Parse(linea);

            perimetro = ladocuadrado * 4;

            Console.WriteLine("el perimetro es:");
            Console.WriteLine(perimetro);

            Console.ReadKey();
        }
    }
}
