﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /*Elaborar una interfaz gráfica que muestre una calculadora (utilizar
objetos de la clase Button y un objeto de la clase Label donde se
muestra el valor ingresado), tener en cuenta que solo se debe
implementar la interfaz y la carga de un valor de hasta 12 dígitos.*/
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength<12)
            {
                string r=textBox1.Text;
                r=r+1;
                textBox1.Text = r;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 2;
                textBox1.Text = r;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 3;
                textBox1.Text = r;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 4;
                textBox1.Text = r;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 5;
                textBox1.Text = r;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 6;
                textBox1.Text = r;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 7;
                textBox1.Text = r;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 8;
                textBox1.Text = r;
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 9;
                textBox1.Text = r;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.TextLength < 12)
            {
                string r = textBox1.Text;
                r = r + 0;
                textBox1.Text = r;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
