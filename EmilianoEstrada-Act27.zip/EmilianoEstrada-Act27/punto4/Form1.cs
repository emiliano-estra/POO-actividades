﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto4
{
    public partial class Form1 : Form
    {/*Se quiere crear un formulario de opinión para un producto.
Requisitos:
● Un Label debe indicar: &quot;Escribe tu opinión&quot;.
● Incluir un TextBox grande (multilínea) donde el usuario escriba su comentario.
● Dos RadioButton deben permitir seleccionar sí recomiendan el producto: &quot;Sí&quot; o &quot;No&quot;.
● Al hacer clic en el botón &quot;Enviar&quot;, se debe mostrar un Label con el mensaje: &quot;Opinión
recibida: [texto] – Recomendación: [Sí/No]&quot;.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text =textBox1.Text;
            if (radioButton1.Checked == true)
            {
                label3.Text =label3.Text+"\n "+ radioButton1.Text;
            }
            if (radioButton2.Checked == true)
            {
                label3.Text = label3.Text + " \n" + radioButton2.Text;
            }
        }
    }
}
