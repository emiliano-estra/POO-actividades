﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto2
{
    public partial class Form1 : Form
    {/*Una aplicación quiere conocer los gustos musicales de los usuarios.
Requisitos:
● Mostrar un ComboBox con 5 géneros musicales distintos.
● Incluir tres CheckBox que representen actividades relacionadas (por ejemplo:
&quot;Escuchar en vivo&quot;, &quot;Escuchar en streaming&quot;, &quot;Comprar discos&quot;).
● Al presionar un botón &quot;Mostrar Preferencias&quot;, en un Label se debe mostrar el género
seleccionado y las actividades marcadas.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text =comboBox1.Text;
            if (checkBox1.Checked == true)
            {
                label2.Text = label2.Text +" "+ checkBox1.Text;
            }
            if (checkBox2.Checked == true)
            {
                label2.Text = label2.Text +" " + checkBox2.Text;
            }
            if (checkBox3.Checked == true)
            {
                label2.Text = label2.Text+" " + checkBox3.Text;
            }
        }
    }
}
