﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto2
{
    public partial class Form1 : Form
    {/*Consigna: Disponer un TextBox para el ingreso numérico y dos RadioButton:
&quot;Celsius a Fahrenheit&quot; y &quot;Fahrenheit a Celsius&quot;. Al presionar un Button, realizar la
fórmula correspondiente y mostrar el resultado en un Label.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                double numero =double.Parse(textBox1.Text);
                double resultado=(numero*1.8)+32;
                label1.Text = resultado.ToString();
            }
            if (radioButton2.Checked)
            {
                double numero = double.Parse(textBox1.Text);
                double resultado = (numero -32 )/1.8;
                label1.Text = resultado.ToString();
            }
        }
    }
}
