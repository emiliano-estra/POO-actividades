﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto4
{
    public partial class Form1 : Form
    {
        /*Consigna: Crear un mini-juego donde un Button cuente cuántos clics realiza el
usuario en 10 segundos. Al finalizar el tiempo mediante el Timer, deshabilitar el
botón (Enabled = false) y mostrar el puntaje acumulado en un MessageBox.Show.*/
        public int num = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            num++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if()
        }
    }
}
