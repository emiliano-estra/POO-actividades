﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto1
{
    public partial class Form1 : Form
    {/*Consigna: Crear un formulario con tres TextBox para ingresar notas y un Button
&quot;Calcular&quot;. Convertir los valores con int.Parse() o double.Parse() y mostrar en una
Label el promedio. Si la nota es mayor o igual a 6, cambiar el color del texto de la
etiqueta a verde; de lo contrario, a rojo.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double promedio, suma;
            suma = double.Parse(textBox1.Text);
            suma = suma+double.Parse(textBox2.Text);
            suma = suma + double.Parse(textBox3.Text);
            promedio = suma / 3;
            if (promedio >= 6) { 
            label1.Text=promedio.ToString();
                label1.ForeColor= Color.Green;
            }
            else
            {
                label1.Text = promedio.ToString();
                label1.ForeColor = Color.Red;
            }
        }
    }
}
