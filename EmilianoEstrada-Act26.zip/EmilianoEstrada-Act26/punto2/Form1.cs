﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace punto2
{
    public partial class Form1 : Form
    {/*Permitir el ingreso de dos números en controles de tipo TextBox y mediante
dos controles de tipo RadioButton permitir seleccionar si queremos sumarlos o
restarlos. Al presionar un botón mostrar en el título del Form el resultado de la
operación.*/
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "+";
            int num1=int.Parse(textBox1.Text);
            int num2=int.Parse(textBox2.Text);
            int suma=num1 + num2;
            Text=suma.ToString();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "-";
            int num1 = int.Parse(textBox1.Text);
            int num2 = int.Parse(textBox2.Text);
            int resta = num1 - num2;
            Text = resta.ToString();
        }


    }
}
