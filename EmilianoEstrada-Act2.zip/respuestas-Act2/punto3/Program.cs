﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*3.Se ingresa por teclado un número positivo de uno o dos dígitos(1..99) 
            mostrar un mensaje indicando si el número tiene uno o dos dígitos.(Tener en cuenta que condición 
            debe cumplirse para tener dos dígitos, un número entero)*/
            int num1;
            string linea;

            Console.Write("ingrese un numero de dos o un digito:");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            if (num1 >= 1)
            {
                if (num1 <= 99)
                {
                    if (num1 <= 9)
                    {
                        Console.Write("tiene un digito");
                    }
                    else
                    {
                        Console.Write("tiene dos digitos");
                    }
                }
            }
            Console.ReadKey();
        }
    }
}
