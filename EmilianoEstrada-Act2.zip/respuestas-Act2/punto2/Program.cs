﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*2.Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"*/
            float num1, num2, num3, num4, num5, num6,promedio;
            string linea;
            Console.Write("ingrese una nota:");
            linea = Console.ReadLine();
            num1 = float.Parse(linea);

            Console.Write("ingrese otra nota:");
            linea = Console.ReadLine();
            num2 = float.Parse(linea);

            Console.Write("ingrese otra nota:");
            linea = Console.ReadLine();
            num3 = float.Parse(linea);

            Console.Write("ingrese otra nota:");
            linea = Console.ReadLine();
            num4 = float.Parse(linea);

            Console.Write("ingrese otra nota:");
            linea = Console.ReadLine();
            num5 = float.Parse(linea);

            Console.Write("ingrese otra nota:");
            linea = Console.ReadLine();
            num6 = float.Parse(linea);

            promedio = (num1 + num2 + num3 + num4 + num5 + num6) / 6;

            if (promedio >= 7)
            {
                Console.WriteLine("el promedio es: aprobado");
            }
            else
            {
                Console.WriteLine("el promedio es: desaprobado");
            }
            Console.ReadKey();
        }
    }
}
