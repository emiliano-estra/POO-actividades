﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 4.Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.*/

            string linea;
            int num1, num2, num3;

            Console.Write("ingrese un numero:");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingrese otro numero:");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);


            Console.Write("ingrese otro numero:");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            if (num1 > num2) {
                if (num1 > num3) {
                    Console.WriteLine("el primer numero es el mas grande");
                }
            }
            else { 
                if (num2 > num3)
                {
                    Console.WriteLine("el segundo numero es el mas grande");
                }
                else
                {
                    Console.WriteLine("el tercero numero es el mas grande");
                }
            }
            Console.ReadKey();
        }
    }
}
