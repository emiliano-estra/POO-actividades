﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto1
{
    internal class Program
    {
        static void Main(string[] args)
        {
          /*  1.Realizar un programa que lea por teclado dos números, si el primero es mayor al segundo informar su suma y diferencia,
                en caso contrario informar el producto y la división del primero respecto al segundo.*/
          float num1, num2, division,suma, resta, multiplicacion;
            string linea;
            Console.Write("ingrese un numero:");
            linea = Console.ReadLine();
            num1 = float.Parse(linea);

            Console.Write("ingrese otro numero:");
            linea = Console.ReadLine();
            num2 = float.Parse(linea);

            if (num1 > num2) {
                suma = num1 + num2;
                resta = num1 - num2;
                Console.WriteLine("suma:");
                Console.WriteLine(suma);
                Console.WriteLine("resta:");
                Console.Write(resta);
            }
            else
            {
                multiplicacion = num1 * num2;
                division = num2 / num1;
                Console.WriteLine("multiplicacion:");
                Console.WriteLine(multiplicacion);
                Console.WriteLine("division:");
                Console.Write(division);
            }
            Console.ReadKey();
        }
    }
}
